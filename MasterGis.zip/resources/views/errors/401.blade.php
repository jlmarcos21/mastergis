@extends('layouts.master')

@section('title', '| No Autorizado')
    
@section('content')
    <div class="jumbotron text-center">
        <h1>No Tiene Permisos <i class="fas fa-user-alt-slash"></i></h1>
    </div>
@endsection