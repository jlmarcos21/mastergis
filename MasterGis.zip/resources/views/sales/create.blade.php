@extends('layouts.master')

@section('title', '| Realizar Venta')

@section('content')

    <sale-component></sale-component>
        
@endsection