
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Correo de Bienvenida</title>
</head>

<body yahoo bgcolor="#f6f8f1" style="margin: 0;padding: 0;min-width: 100%!important;">
<table width="100%" bgcolor="#f6f8f1" border="0" cellpadding="0" cellspacing="0">
<tr>
  <td>
    <table bgcolor="#ffffff" class="content" align="center" cellpadding="0" cellspacing="0" border="0" style="width: 100%;max-width: 600px;">
      <tr>
        <td bgcolor="#c10012" class="header" style="padding: 40px 30px 20px 30px;">
          <table width="100%" align="left" border="0" cellpadding="0" cellspacing="0">  
            <tr>
              <td style="padding: 0 20px 20px 0; text-align: center">
                <img class="fix" src="https://www.mastergis.com/wp-content/themes/masterig/images/logo.svg" width="80%" height="100%" border="0" alt="" style="height: auto;">
              </td>
            </tr>
          </table>
          <table class="col425" align="left" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 425px;">  
            <tr>
              <td height="70">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="subhead" style="padding: 0 0 0 3px;font-size: 15px;color: #ffffff;font-family: sans-serif;letter-spacing: 5px;">
                      PASIÓN POR LOS GIS
                    </td>
                  </tr>
                  <tr>
                    <td class="h1" style="padding: 5px 0 0 0;color: #153643;font-family: sans-serif;font-size: 33px;line-height: 38px;font-weight: bold;">
                      Correo de Bienvenida
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td class="innerpadding borderbottom" style="padding: 30px 30px 30px 30px;border-bottom: 1px solid #f2eeed;">
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td class="h2" style="color: #153643;font-family: sans-serif;padding: 0 0 15px 0;font-size: 24px;line-height: 28px;font-weight: bold;">
                Bienvenido {{ $data['student'] }} 
              </td>
            </tr>
            <tr>
              <td class="bodycopy" style="color: #153643;font-family: sans-serif;font-size: 16px;line-height: 22px;">
                Formamos profesionales destacados para que asuman nuevos retos en el mercado laboral.
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td class="footer" bgcolor="#c10012" style="padding: 20px 30px 15px 30px;">
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" class="footercopy" style="font-family: sans-serif;font-size: 14px;color: #ffffff;">
                &copy; MasterGIS 2017<br>                                
              </td>
            </tr>
            <tr>
              <td align="center" style="padding: 20px 0 0 0;">
                <table border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="37" style="text-align: center; padding: 0 10px 0 10px;">
                        <a href="http://www.facebook.com/">
                            <img src="https://image.flaticon.com/icons/svg/145/145802.svg" width="37" height="37" alt="Facebook" border="0" style="height: auto;">
                        </a>
                    </td>
                    <td width="37" style="text-align: center; padding: 0 10px 0 10px;">
                        <a href="http://www.twitter.com/">
                            <img src="https://image.flaticon.com/icons/svg/145/145812.svg" width="37" height="37" alt="Twitter" border="0" style="height: auto;">
                        </a>
                    </td>
                    <td width="37" style="text-align: center; padding: 0 10px 0 10px;">
                        <a href="https://www.instagram.com/">
                          <img src="https://image.flaticon.com/icons/svg/1409/1409946.svg" width="37" height="37" alt="Twitter" border="0" style="height: auto;">
                        </a>
                    </td>
                    <td width="37" style="text-align: center; padding: 0 10px 0 10px;">
                        <a href="https://www.youtube.com/">
                          <img src="https://image.flaticon.com/icons/svg/1384/1384060.svg" width="37" height="37" alt="Twitter" border="0" style="height: auto;">
                        </a>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>

<!--analytics-->
<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
<script src="http://tutsplus.github.io/github-analytics/ga-tracking.min.js"></script>
</body>
</html>