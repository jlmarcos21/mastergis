<div class="row">

    <div class="form-group col-md-4">
        <?php echo e(Form::label('name', 'Nombre del Estudiante')); ?>

        <?php echo e(Form::text('name', null, ['class' => 'form-control border border-success', 'id' => 'name', 'required', 'maxlength' => '150', 'autofocus'])); ?>

    </div>
    
    <div class="form-group col-md-4">
        <?php echo e(Form::label('lastname', 'Apellido del Estudiante')); ?>

        <?php echo e(Form::text('lastname', null, ['class' => 'form-control border border-success', 'id' => 'lastname', 'required', 'maxlength' => '150'])); ?>

    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label(null, 'Sexo del Estudiante')); ?>

        <select name="sex" id="sex" class="selectpicker form-control" data-size="5" data-style="border border-success" data-live-search="true" title="Selecciona El Sexo" required>            
            <option                    
            <?php if(isset($student)): ?>
                <?php echo e(old('sex',$student->sex)=='MASCULINO'? 'selected':''); ?>

            <?php endif; ?>
            value="MASCULINO" data-icon="fas fa-male text-primary">
                MASCULINO
            </option>
            <option
            <?php if(isset($student)): ?>
                <?php echo e(old('sex',$student->sex)=='FEMENINO'? 'selected':''); ?>

            <?php endif; ?>
            value="FEMENINO" data-icon="fas fa-female text-danger">
                FEMENINO
            </option>            
        </select>
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('country_id', 'País del Estudiante')); ?>

        <select name="country_id" id="country_id" class="selectpicker form-control" data-size="5" data-style="border border-success" data-live-search="true" title="Selecciona su País" required>
            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($country->id); ?>" data-icon="<?php echo e($country->flag); ?>"
                    <?php if(isset($student)): ?>
                        <?php if($student->country_id==$country->id): ?>
                            selected 
                        <?php endif; ?>
                    <?php endif; ?>>
                        <?php echo e($country->description); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>              
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('email', 'Correo del Estudiante')); ?>

        <?php echo e(Form::text('email', null, ['class' => 'form-control border border-success', 'id' => 'email', 'required', 'maxlength' => '240'])); ?>

    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('phone', 'Celular del Estudiante')); ?>

        <?php echo e(Form::text('phone', null, ['class' => 'form-control border border-success', 'id' => 'phone', 'maxlength' => '25'])); ?>

    </div>

    <div class="form-group col-md-12">
        <button class="btn btn-primary">Guardar Datos</button>
        <a href="<?php echo e(route('students.index')); ?>" class="btn btn-danger">Cancelar</a>        
    </div>
</div>