<div class="row">

    <div class="form-group col-md-3">
        <?php if($assignment->access==0): ?>
            <div class="custom-control custom-checkbox">
                <?php echo e(Form::checkbox("access", "1", old('access'), ["class" => "custom-control-input", "id" => "access"])); ?>

                <label class="custom-control-label" for="access">Acceso</label>
            </div>
        <?php else: ?>
            <span class="text-success">Acceso Otorgado</span>
        <?php endif; ?>        
    </div>
    <div class="form-group col-md-3">
        <?php if($assignment->entry==0): ?>
            <div class="custom-control custom-checkbox">
                <?php echo e(Form::checkbox("entry", "1", old('entry'), ["class" => "custom-control-input", "id" => "entry"])); ?>   
                <label class="custom-control-label" for="entry">Ingreso</label>
            </div>            
        <?php else: ?>
            <span class="text-success">Ingreso Correcto</span>
        <?php endif; ?> 
    </div>        
    <div class="form-group col-md-3">
        <?php if($assignment->poll==0): ?>
            <div class="custom-control custom-checkbox">
                <?php echo e(Form::checkbox("poll", "1", old('poll'), ["class" => "custom-control-input", "id" => "poll"])); ?>

                <label class="custom-control-label" for="poll">Encuesta</label>
            </div>
        <?php else: ?>
            <span class="text-success">Encuesta Realizada</span>
        <?php endif; ?>
    </div>
    <div class="form-group col-md-3">
        <?php if($assignment->physical_certificate==0): ?>
            <div class="custom-control custom-checkbox">
                <?php echo e(Form::checkbox("physical_certificate", "1", old('physical_certificate'), ["class" => "custom-control-input", "id" => "physical_certificate"])); ?>

                <label class="custom-control-label" for="physical_certificate">Certificado Fisico</label>
            </div>
        <?php else: ?>
            <span class="text-success">Certificado Fisico Entregado</span>
        <?php endif; ?>
    </div>
    <div class="form-group col-md-12">
        <?php if($assignment->access==0 || $assignment->entry==0 || $assignment->poll==0 || $assignment->physical_certificate==0): ?>
            <button class="btn btn-success">Actualizar</button>
        <?php endif; ?>
        <a href="<?php echo e(route('assignments.show', $assignment->code)); ?>" class="btn btn-danger">Regresar</a>        
    </div>

</div>