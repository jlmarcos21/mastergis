<?php $__env->startSection('title', '| Realizar Venta'); ?>

<?php $__env->startSection('content'); ?>

    <sale-component></sale-component>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>