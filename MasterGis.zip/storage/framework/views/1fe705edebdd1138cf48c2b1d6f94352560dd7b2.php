<?php $__env->startSection('title', '| Proceso Asignación'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3>Proceso de Asignación</h3>
        </div>
        <div class="card-body">
            <?php echo Form::model($assignment, ['route' => ['assignments.update', $assignment->id], 'method' => 'PUT', 'files' => true]); ?>

                        
                <?php echo $__env->make('assignments.form.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>