<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Detalle del Mensaje</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <?php echo Form::open(['route' => 'send.email', 'method' => 'POST']); ?>

            <div class="row">
                <div class="col-md-12 form-group">
                    <div class="form-group">
                        <div class="input-group">
                            <input type="text" class="form-control" name="from" placeholder="De:">
                            <input type="text" class="form-control" name="subject" placeholder="Titulo:">
                        </div>
                    </div>

                    <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(Form::hidden('emails[]', $assignment->student->email)); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <textarea name="editor" id="editor" rows="10" cols="80" class="form-control">
                        Mensaje a enviar
                    </textarea>
                </div>
                <div class="col-md-12">
                    <button type="submit" class="btn btn-block btn-primary">Enviar Correos</button>
                </div>
            </div>
            
            <?php echo Form::close(); ?>     
        </div>
        </div>
    </div>
</div>