<?php $__env->startSection('title', '| Cronograma de Asiganciones de Estudiantes'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">        

        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3>Filtrar Asiganciones</h3>
                </div>
                <div class="card-body">
                    <?php echo Form::open(['route' => 'schedules', 'method' => 'GET']); ?>

                    <div class="row">
                        <div class="col-md-3 form-group">                            
                            <?php echo e(Form::label('date_s', 'Fecha de Inicio')); ?>

                            <?php echo e(Form::date('date_s', (isset($request->date_s))?$request->date_s:'', ['class' => 'form-control border border-success text-center', 'id' => 'date_s', 'required'])); ?>                                                                                     
                        </div>
                        <div class="col-md-3 form-group">                            
                            <?php echo e(Form::label('date_f', 'Fecha de Final')); ?>

                            <?php echo e(Form::date('date_f', (isset($request->date_f))?$request->date_f:'', ['class' => 'form-control border border-success text-center', 'id' => 'date_f', 'required'])); ?>                                                                                     
                        </div>
                        <div class="col-md-2 form-group">             
                            <label for="">&nbsp</label>               
                            <div class="custom-control custom-checkbox form-control text-center">
                                <?php echo e(Form::checkbox("entry", "1", (isset($request->entry))?$request->entry:'', ["class" => "custom-control-input", "id" => "entry"])); ?>

                                <label class="custom-control-label" for="entry">Ingreso</label>
                            </div>
                        </div>
                        <div class="col-md-2 form-group">             
                            <label for="">&nbsp</label>               
                            <div class="custom-control custom-checkbox form-control text-center">
                                <?php echo e(Form::checkbox("poll", "1", (isset($request->poll))?$request->poll:'', ["class" => "custom-control-input", "id" => "poll"])); ?>

                                <label class="custom-control-label" for="poll">Encuesta</label>
                            </div>
                        </div>
                        <div class="col-md-2 form-group">             
                            <label for="">&nbsp</label>               
                            <div class="custom-control custom-checkbox form-control text-center">
                                <?php echo e(Form::checkbox("finished", "1", (isset($request->finished))?$request->finished:'', ["class" => "custom-control-input", "id" => "finished"])); ?>

                                <label class="custom-control-label" for="finished">Terminado</label>
                            </div>
                        </div>
                        <div class="col-md-12">                            
                            <button type="submit" class="btn btn-block btn-primary">Filtrar Asignaciones <i class="fas fa-search"></i></button>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
                <?php if(isset($assignments)): ?>
                <?php echo $__env->make('schedules.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>                                   
                <div class="card-footer table-responsive">
                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#">
                        Enviar Correo
                    </button>
                    <hr>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Estudiante</th>
                                <th>Curso</th>                                
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($assignment->code); ?></td>
                                <td><?php echo e($assignment->student->name); ?> <?php echo e($assignment->student->lastname); ?></td>
                                <td><?php echo e($assignment->course->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('vendor\ckeditor\ckeditor.js')); ?>"></script>
    <script>
        $(() => {
            CKEDITOR.replace('editor');
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>