<?php $__env->startSection('title', '| Consulta de Ventas'); ?>

<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.css"/>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3>Filtrado de Ventas Por Fechas</h3>
                </div>
                <div class="card-body">
                    <?php echo Form::open(['route' => 'search_sales', 'method' => 'GET']); ?>

                        <div class="row">
                            <div class="col-md-2">
                                <?php echo e(Form::label('date_s', 'Fecha de Inicio')); ?>

                                <?php echo e(Form::date('date_s', (isset($request->date_s))?$request->date_s:'', ['class' => 'form-control border border-success', 'id' => 'date_s', 'required'])); ?>

                            </div>
                            <div class="col-md-2">
                                <?php echo e(Form::label('date_f', 'Fecha Final')); ?>

                                <?php echo e(Form::date('date_f', (isset($request->date_f))?$request->date_f:'', ['class' => 'form-control border border-success', 'id' => 'date_f', 'required'])); ?>

                            </div>
                            <div class="col-md-3">
                                    <?php echo e(Form::label('searchpayment', 'Pago')); ?>

                                    <select name="searchpayment" id="searchpayment" class="form-control">
                                        <option value="">Todos</option>
                                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
    
                                        <option value="<?php echo e($payment->id); ?>"
                                            <?php if(isset($request->searchpayment)): ?>
                                                <?php if($payment->id==$request->searchpayment): ?>
                                                    selected
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            ><?php echo e($payment->name); ?>

                                        </option>
    
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            <div class="col-md-2">
                                <?php echo e(Form::label('searchvoucher', 'Comprobante')); ?>

                                <select name="searchvoucher" id="searchvoucher" class="form-control">
                                    <option value="">Todos</option>
                                    <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                         

                                    <option value="<?php echo e($voucher->id); ?>"
                                        <?php if(isset($request->searchvoucher)): ?>
                                            <?php if($voucher->id==$request->searchvoucher): ?>
                                                selected
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        ><?php echo e($voucher->name); ?>

                                    </option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                    <?php echo e(Form::label('searchcurrency', 'Moneda')); ?>

                                    <select name="searchcurrency" id="searchcurrency" class="form-control">
                                        <option value="">Todos</option>
                                        <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                             

                                        <option value="<?php echo e($currency->id); ?>"
                                            <?php if(isset($request->searchcurrency)): ?>
                                                <?php if($currency->id==$request->searchcurrency): ?>
                                                    selected
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            ><?php echo e($currency->name); ?>

                                        </option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            <div class="col-md-1">
                                <?php echo e(Form::label('date_f', 'Filtrar')); ?>                                
                                <button type="submit" class="btn btn-block btn-primary"><i class="fas fa-search"></i></button>
                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>                
                <div class="card-footer">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive py-3">                                    
                                <?php echo $dataTable->table(); ?>                                       
                            </div>
                        </div>
                    </div>
                </div>                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>    
    <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
    <script src="/vendor/datatables/buttons.server-side.js"></script>
    <?php echo $dataTable->scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>