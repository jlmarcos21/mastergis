<?php $__env->startSection('title', '| Perfil del Estudiante'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-8">
    <h3><strong>Cursos Comprados</strong></h3>
    <hr>
    <div class="row">
      <?php $__currentLoopData = $student->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 py-2">
        <div class="card text-center card-bg" onclick="location.href='<?php echo e(route('assignments.show', $assignment->code)); ?>'" title="Realizar Seguimiento">
          <img src="<?php echo e($assignment->course->image_url); ?>" class="card-img-top" alt="<?php echo e($assignment->course->name); ?>">
          <div class="card-body">
            <p class="card-text"><?php echo e($assignment->course->name); ?></p>
            <p class="text-muted"><?php echo e($assignment->code); ?></p>

            <?php if($assignment->finished): ?>
              <strong class="text-success">Curso Terminado</strong>
            <?php else: ?>
              <strong class="text-danger">No Terminado</strong>
            <?php endif; ?>

          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
    </div>
  </div>
  <div class="col-md">
    <ul class="list-group">
      <li class="list-group-item bg-primary text-center text-white"><h4>Datos del Estudiante</h4></li>
      <li class="list-group-item"><strong>Nombre :</strong> <?php echo e($student->name); ?></li>
      <li class="list-group-item"><strong>Apellido :</strong> <?php echo e($student->lastname); ?></li>
      <li class="list-group-item"><strong>Sexo :</strong> <?php echo e($student->sex); ?></li>    
      <li class="list-group-item"><strong>Nacionalidad :</strong> <?php echo e($student->nationality); ?></li>
      <li class="list-group-item"><strong>País :</strong> <?php echo e($student->country->description); ?> <span class="<?php echo e($student->country->flag); ?>"></span></li>      
      <li class="list-group-item"><strong>Correo :</strong> <?php echo e($student->email); ?></li>
      <li class="list-group-item"><strong>Celular :</strong> <?php echo e($student->phone); ?></li>      
    </ul>
  </div>
</div>

<div class="row py-3">
  <div class="col-md-12">
    <div class="d-flex justify-content-center bg-primary text-white p-4">
      <div class="px-5">
          <div class="mb-2">Total de Cursos</div>
          <div class="h2 font-weight-light text-center"><i class="fas fa-book"></i> <?php echo e($student->assignments->count()); ?></div>
      </div>
    
      <div class="px-5">
          <div class="mb-2">Total de Compras</div>
          <div class="h2 font-weight-light text-center"><i class="fas fa-shopping-cart"></i> <?php echo e($student->sales->count()); ?></div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>