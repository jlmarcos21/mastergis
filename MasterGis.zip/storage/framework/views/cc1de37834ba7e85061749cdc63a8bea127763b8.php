<?php $__env->startSection('title', '| Lista de Asignaciones'); ?>

<?php $__env->startSection('links'); ?>
    <style>
    
    .img-zoom{                
        overflow: hidden;
        cursor: pointer;   
    }

    .img-hover-zoom img {
        transition: transform .5s ease;
    }

    /* [3] Finally, transforming the image when container gets hovered */
    .img-hover-zoom:hover img {
        transform: scale(1.5);
    }
}

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 py-2">
            <div class="w-100 img-zoom img-hover-zoom">
                <img src="<?php echo e($course->image_url); ?>" class="img-fluid rounded" style="cursor: pointer" alt="<?php echo e($course->name); ?>" data-toggle="tooltip" data-placement="bottom" title="Total de Estudiantes <?php echo e($course->assignments->count()); ?>" onclick="location.href='<?php echo e(route('show_assignments', $course->id)); ?>'">
            </div>            
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>