<?php echo Form::open(['route' => ['students.destroy', $id], 'method' => 'DELETE']); ?>

    <?php if($state==1): ?>
        <button class="btn btn-sm btn-danger">
            Desactivar
        </button>
    <?php else: ?>
        <button class="btn btn-sm btn-success">
            Activar
        </button>
    <?php endif; ?>                           
<?php echo Form::close(); ?>