<?php $__env->startSection('title', '| Actualizar Curso'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3>Actualizar de Curso</h3>
        </div>
        <div class="card-body">
            <?php echo Form::model($course, ['route' => ['courses.update', $course->id], 'method' => 'PUT', 'files' => true]); ?>

                        
                <?php echo $__env->make('courses.form.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>