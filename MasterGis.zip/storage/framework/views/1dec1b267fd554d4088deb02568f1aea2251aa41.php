<?php $__env->startSection('title', '| Detalle de Asignacion'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table text-center table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>Fecha de Inicio <i class="far fa-calendar-check"></i></th>                            
                            <th>Fecha de Final <i class="far fa-calendar-times"></i></th>
                            <th>Dias Restantes</th>
                            <th>Generar Certificado</th>                                        
                            <th>Actualizar</th>            
                        </tr>
                    </thead>
                    <tbody>                        
                        <tr>
                            <td><span class="text-success"><?php echo e($assignment->start_date); ?></span></td>
                            <td><span class="text-danger"><?php echo e($assignment->final_date); ?></span></td>
                            <td><?php echo $assignment->remaining_days<0?'<span class="text-danger">Curso Vencido</span>':'<span class="text-success">'.$assignment->remaining_days.'</span>'; ?></td>
                            <td>
                                <?php if($assignment->finished): ?>
                                    <a href="<?php echo e(route('generate-certificate', $assignment->code)); ?>" target="_blank" class="btn btn-sm btn-dark" title="Generar Certificado">Generar Certificado</a>                                    
                                <?php else: ?>
                                    <span class="text-danger">Proceso...</span>
                                <?php endif; ?>                                
                            </td>                            
                            <td>
                                <a href="<?php echo e(route('assignments.edit', $assignment->id)); ?>" class="btn btn-sm btn-success" title="Actualizar Seguimiento"><i class="far fa-edit"></i></a>
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <table class="table text-center table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>Código</th>
                            <th>Estudiante</th>
                            <th>Curso</th>
                            <th>Nivel</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($assignment->code); ?></td>
                            <td><?php echo e($assignment->student->name); ?>, <?php echo e($assignment->student->lastname); ?></td>
                            <td><?php echo e($assignment->course->name); ?></td>
                            <td><i class="fas fa-circle" style="color:<?php echo e($assignment->course->level->colour); ?>"> <?php echo e($assignment->course->level->description); ?></i></td>
                        </tr>
                    </tbody>
                </table>
                
                <table class="table text-center table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th width="10px">Acceso</th>
                            <th width="10px">Ingreso</th>
                            <th>C.Básico</th>
                            <th>C.Intermedio</th>
                            <th>C.Avanzado</th>
                            <th>Certificado</th>
                            <th>Estado</th>
                            <th width="10px">Encuesta</th>             
                            <th>Certificado.F</th>                                                       
                        </tr>
                    </thead>
                    <tbody>                        
                        <tr>                            
                            <td>
                                <?php echo $assignment->access=='0'?'<strong class="text-danger">NO</strong>':'<strong class="text-success">SI</strong>'; ?>

                            </td>
                            <td>
                                <?php echo $assignment->entry=='0'?'<strong class="text-danger">NO</strong>':'<strong class="text-success">SI</strong>'; ?>

                            </td>
                            <td>
                                <?php echo $assignment->basic_constancy=='0'?'<strong class="text-danger">NO</strong>':'<strong class="text-success">SI</strong>'; ?>

                            </td>
                            <td>
                                <?php echo $assignment->intermediate_constancy=='0'?'<strong class="text-danger">NO</strong>':'<strong class="text-success">SI</strong>'; ?>

                            </td>
                            <td>
                                <?php echo $assignment->advanced_constancy=='0'?'<strong class="text-danger">NO</strong>':'<strong class="text-success">SI</strong>'; ?>

                            </td>
                            <td>
                                <?php echo $assignment->certificate=='0'?'<strong class="text-danger">NO</strong>':'<strong class="text-success">SI</strong>'; ?>

                            </td>
                            <td>
                                <?php echo $assignment->finished=='0'?'<strong class="text-danger">No Terminado</strong>':'<strong class="text-success">Curso Terminado</strong>'; ?>

                            </td> 
                            <td>
                                <?php echo $assignment->poll=='0'?'<strong class="text-danger">NO</strong>':'<strong class="text-success">SI</strong>'; ?>

                            </td>
                            <td>
                                <?php echo $assignment->physical_certificate=='0'?'<strong class="text-danger">NO</strong>':'<strong class="text-success">SI</strong>'; ?>

                            </td>                                                       
                        </tr>          
                    </tbody>
                </table>                            
            </div>
        </div>
        <div class="col-md-12">
            <div class="d-flex bd-highlight">
                <div class="mr-auto p-2 bd-highlight">
                    <a href="<?php echo e(route('assignments.index')); ?>" class="btn btn-sm btn-danger"><i class="fas fa-arrow-circle-left"></i></a>
                </div>
                <?php if(($assignment->access) && ($assignment->entry)): ?>
                    <div class="p-2 bd-highlight">
                        <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#projectModal" data-backdrop="static" <?php echo e($assignment->finished?'DISABLED':''); ?>>
                            Añadir Proyectos
                        </button>
                    </div>            
                <?php endif; ?>                
            </div>                                                
        </div>
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-bordered text-center">
                    <thead>
                        <th>Nivel</th>
                        <th>Descrición</th>                        
                        <th>Estado</th>
                        <th width="15%">Fecha</th>
                        <th>Constancia</th>
                        <th>Observaciones</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $assignment->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><i class="fas fa-circle" style="color:<?php echo e($project->sub_level->colour); ?>"> <?php echo e($project->sub_level->description); ?></i></td>
                                <td><?php echo e($project->description); ?></td>
                                <td>
                                    <?php echo $project->state=='0'?'<span class="text-danger">Desaprobado</span>':'<span class="text-success">Aprobado</span>'; ?>

                                </td>
                                <td><?php echo e($project->date); ?></td>
                                <th width="10px">
                                    <?php if($project->state==1): ?>
                                        <a href="<?php echo e(route('generate-constancy', $project->id)); ?>" target="_blank" class="btn btn-sm btn-danger">Constancia</a>
                                    <?php else: ?>
                                    <h3 class="far fa-sad-cry text-danger"></h3>
                                    <?php endif; ?>
                                </th>
                                <th width="10px">
                                    <a href="<?php echo e(route('generate-annotation', $project->id)); ?>" target="_blank" class="btn btn-sm btn-danger">Observaciones</a>
                                </th>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>        
    </div>    
    <?php echo $__env->make('assignments.form.project', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>