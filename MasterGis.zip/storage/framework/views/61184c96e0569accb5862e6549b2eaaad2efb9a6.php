<div class="row">

        <div class="form-group col-md-4">
            <?php echo e(Form::label('name', 'Nombre del Curso')); ?>

            <?php echo e(Form::text('name', null, ['class' => 'form-control border border-success', 'id' => 'name', 'required', 'maxlength' => '150', 'autofocus'])); ?>

        </div>

        <div class="form-group col-md-4">
            <?php echo e(Form::label('certificate', 'Certificado del Curso')); ?>

            <?php echo e(Form::text('certificate', null, ['class' => 'form-control border border-success', 'id' => 'certificate', 'required', 'maxlength' => '150', 'autofocus'])); ?>

        </div>
        
        <div class="form-group col-md-4">
            <?php echo e(Form::label('code', 'Codigo del Curso')); ?>

            <?php echo e(Form::text('code', null, ['class' => 'form-control border border-success', 'id' => 'code', 'required', 'maxlength' => '150'])); ?>

        </div>            
    
        <div class="form-group col-md-4">
            <?php echo e(Form::label('level_id', 'Nivel del Curso')); ?>

            <select name="level_id" id="level_id" class="selectpicker form-control" data-style="border border-success" data-live-search="true" title="Seleccionar Niveles" required>
                <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($level->id); ?>" data-content="<i class='fas fa-circle' style='color:<?php echo e($level->colour); ?>'></i> <strong><?php echo e($level->description); ?></strong>"
                        <?php if(isset($course)): ?>
                            <?php if($course->level_id==$level->id): ?>
                                selected
                            <?php endif; ?>
                        <?php endif; ?>>                            
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>                  
        </div>
    
        <div class="form-group col-md-4">
            <?php echo e(Form::label('duration', 'Duración del Curso')); ?>

            <?php echo e(Form::text('duration', null, ['class' => 'form-control border border-success', 'id' => 'duration', 'required', 'maxlength' => '240'])); ?>

        </div>
    
        <div class="form-group col-md-4">
            <?php echo e(Form::label('image_url', 'Imagen del Curso')); ?> <?php if(isset($course)): ?> <a href="<?php echo e($course->image_url); ?>" target="_blank">(Ver Imagen)</a> <?php endif; ?> 
            <?php echo e(Form::text('image_url', null, ['class' => 'form-control border border-success', 'id' => 'image_url'])); ?>

        </div>
    
        <div class="form-group col-md-12">
                <button class="btn btn-primary">Guardar Datos</button>
            <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-danger">Cancelar</a>            
        </div>
    </div>